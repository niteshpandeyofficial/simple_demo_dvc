from setuptools import find_packages, setup

setup(
    name="src",
    version="0.0",
    description="Its dvc demo",
    author="Nitesh Pandey",
    packages=find_packages(),
    license="MIT"
)